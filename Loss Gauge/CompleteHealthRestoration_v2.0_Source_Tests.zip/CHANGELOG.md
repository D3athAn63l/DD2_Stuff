## v2.0 — 2026-10-11 (experimental)
- Fixed ImGui change flags incorrectly discarding earlier edits.
- Fixed silent JSON dump failures and moved config to REFramework's top-level data directory.
- Migrates legacy `renpyon/CompleteHealthRestoration.json` where available; preserves false boolean settings.
- Reads health from `app.Character` and writes reduced maximum health via character Hit controller; legacy fallback.
- Changed gauge regen formula to percent of original max HP/sec for linear recovery.
- Uses current `get_BattleMode` API first; retains old fallback.
- Adds load-safe managers, late-update scheduling with frame fallback, read-only health diagnostics.
- Tested with mocked REFramework runtime, **not yet in game**.
