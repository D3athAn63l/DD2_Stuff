import ctypes
from pathlib import Path
root=Path(__file__).resolve().parents[1]
lib=ctypes.CDLL('liblua5.4.so.0')
lib.luaL_newstate.restype=ctypes.c_void_p
lib.luaL_openlibs.argtypes=[ctypes.c_void_p]
lib.luaL_loadstring.argtypes=[ctypes.c_void_p,ctypes.c_char_p];lib.luaL_loadstring.restype=ctypes.c_int
lib.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_long,ctypes.c_void_p];lib.lua_pcallk.restype=ctypes.c_int
lib.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lib.lua_tolstring.restype=ctypes.c_char_p
lib.lua_close.argtypes=[ctypes.c_void_p]
L=lib.luaL_newstate();lib.luaL_openlibs(L)
try:
    source=root/'reframework/autorun/CompleteHealthRestoration.lua'
    test=root/'tests/test_complete_health_restoration.lua'
    code=f'CHR_SOURCE={str(source)!r}\ndofile({str(test)!r})'
    rc=lib.luaL_loadstring(L,code.encode())
    if rc==0:rc=lib.lua_pcallk(L,0,-1,0,0,None)
    if rc!=0:raise RuntimeError(lib.lua_tolstring(L,-1,None).decode(errors='replace'))
    print('All Lua 5.4 mocked-runtime tests passed')
finally:lib.lua_close(L)
