-- Self-contained Lua 5.4 test harness; run via run_tests.py
local SOURCE = assert(CHR_SOURCE)
local saved = {}
local writes = 0
local toggles = {}
local clock = 0
os.clock = function() return clock end

local legacy = {
    GaugeHealEnabled = true,
    GaugeHealPerc = 0.2,
    GaugeHealInBattle = false,
    GaugeHealArisen = true,
    GaugeHealPawn = true,
    AutoHealEnable = true,
    AutoHealPerc = 1.0,
    AutoHealToMaxHP = false,
    AutoHealBattleRatio = 0.2,
    AutoHealTargetHP = 100,
    AutoHealArisen = true,
    AutoHealPawn = true,
}
local function deepclone(x)
    if type(x) ~= 'table' then return x end
    local y = {}
    for k,v in pairs(x) do y[k] = deepclone(v) end
    return y
end

json = {
    load_file = function(path)
        if saved[path] then return deepclone(saved[path]) end
        if path == 'renpyon\\CompleteHealthRestoration.json' then return deepclone(legacy) end
        return nil
    end,
    dump_file = function(path, data)
        writes = writes + 1
        saved[path] = deepclone(data)
        return true
    end,
}

local function make_character(hp, reduced, original)
    local char = {valid=true, hp=hp, reduced=reduced, original=original, hpWrites=0, gaugeWrites=0}
    local hit = {parent=char}
    function hit:set_ReducedMaxHp(value)
        self.parent.gaugeWrites = self.parent.gaugeWrites + 1
        self.parent.reduced = value
    end
    function hit:setHpValue(value, no)
        assert(no == false)
        self.parent.hpWrites = self.parent.hpWrites + 1
        self.parent.hp = math.min(value, self.parent.reduced)
    end
    char.hit = hit
    function char:get_field(k)
        if k == '<Hit>k__BackingField' then return self.hit end
    end
    function char:call(name, arg)
        if name:match('^get_Valid') then return self.valid end
        if name:match('^get_Hp') then return self.hp end
        if name:match('^get_ReducedMaxHp') then return self.reduced end
        if name:match('^get_OriginalMaxHp') then return self.original end
        error('unknown character method ' .. name)
    end
    return char
end
local player = make_character(400, 600, 1000)
local pawn = make_character(450, 500, 900)
local paused = false
local battle_mode = 0
local pawnlist = {}
function pawnlist:call(name, idx)
    if name:match('^get_Count') then return 1 end
    if name:match('^get_Item') then assert(idx==0); return pawn end
    error(name)
end
local managers = {
    ['app.CharacterManager'] = {call=function(self,name) if name:match('^get_ManualPlayer') then return player end end},
    ['app.PawnManager'] = {call=function(self,name) if name:match('^get_PawnCharacterList') then return pawnlist end end},
    ['app.GuiManager'] = {call=function(self,name) if name:match('^isPausedGUI') then return paused end end},
    ['app.BattleManager'] = {call=function(self,name) if name:match('^get_BattleMode') then return battle_mode end end},
}
sdk = {get_managed_singleton=function(name) return managers[name] end}
log = {info=function() end}
local late, frame, draw
re = {
    on_application_entry = function(which, callback) assert(which=='LateUpdateBehavior'); late=callback end,
    on_frame = function(callback) frame=callback end,
    on_draw_ui = function(callback) draw=callback end,
}
imgui = {
    tree_node=function() return true end,
    tree_pop=function() end,
    spacing=function() end,
    text=function(message) end,
    button=function() return false end,
    checkbox=function(label, current)
        if toggles[label]~=nil then local value=toggles[label];toggles[label]=nil;return true,value end
        return false,current
    end,
    drag_float=function(label, current)
        if toggles[label]~=nil then local value=toggles[label]; toggles[label]=nil; return true,value end
        return false,current
    end,
}
assert(loadfile(SOURCE))()
assert(type(late)=='function' and type(frame)=='function' and type(draw)=='function')
assert(saved['CompleteHealthRestoration.json'].GaugeHealEnabled == true, 'legacy migration failed')
local startWrites = writes
local function advance(dt)
    clock=clock+dt
    late()
    frame()
end
advance(0.2)
assert(player.gaugeWrites>0, 'Arisen loss gauge not restored')
assert(player.reduced>600, 'Arisen reduced maximum should increase')
assert(player.hp>400, 'Arisen normal HP should increase')
assert(pawn.reduced>500 and pawn.hp>450, 'Pawn health not restored')
local before = player.reduced
battle_mode=1
advance(0.2)
assert(player.reduced == before, 'Loss gauge must pause in battle by default')
assert(player.hpWrites>=2, 'HP battle healing should remain enabled')
battle_mode=0
paused=true
before=player.reduced
advance(0.2)
assert(player.reduced == before, 'Pause should stop restoration')
paused=false
-- Multiple toggles in one UI pass must save their values, including false booleans.
toggles['Loss Gauge restoration enabled'] = false
toggles['HP healing enabled'] = false
toggles['Gauge rate (%)'] = 4.5
draw()
local new = saved['CompleteHealthRestoration.json']
assert(new.GaugeHealEnabled==false and new.AutoHealEnable==false, 'false toggles not saved')
assert(new.GaugeHealPerc==4.5, 'changed rate not saved')
assert(writes==startWrites+1, 'expected exactly one save for multiple UI changes')
local count=player.hpWrites
advance(0.2)
assert(player.hpWrites == count, 'disabled health restoration still running')
-- Simulate save failing without throw and ensure the UI exposes a failure message.
local real_dump=json.dump_file
json.dump_file=function() return false end
toggles['HP healing enabled'] = true
draw()
assert(writes==startWrites+1, 'failed write path test')
json.dump_file=real_dump
-- Fresh script load reads saved config (false values preserved) rather than legacy file.
local saved_count=writes
assert(loadfile(SOURCE))()
assert(writes==saved_count, 'reload should not rewrite existing settings')
local previous_gauge=player.reduced
local previous_hp=player.hp
advance(0.3)
assert(player.reduced==previous_gauge and player.hp==previous_hp, 'persisted settings not loaded after restart')
print('PASS: migration, health, gauge, pawns, battle/pause, settings multi-save, disabled, dump failure, reload')
