# Complete Health Restoration v2.0 — Standalone Experimental

Updates the user's original Dragon's Dogma 2 REFramework Lua mod. Uses the attached SmoothAutoRestoreHP v1.1 **only as an implementation reference**; it is **not bundled, installed, or required**.

## Installation

1. Back up your save and your old `reframework/data/renpyon/CompleteHealthRestoration.json` if present.
2. Remove/replace any *old* `CompleteHealthRestoration.lua` in `reframework/autorun`. Keep only one version.
3. Copy the `reframework` directory from the installable ZIP into the DD2 game directory (the directory containing `DragonsDogma2.exe`). The script should end up at `reframework/autorun/CompleteHealthRestoration.lua`.
4. **Do not run SmoothAutoRestoreHP or another HP/loss-gauge regeneration mod at the same time.**
5. In-game, press Insert, open `Script Generated UI > Complete Health Restoration v2.0`.

## What changed

- **Loss Gauge path:** reads `Hp`, `ReducedMaxHp`, and `OriginalMaxHp` from the character, and restores reduced max HP using the character's Hit controller (`<Hit>k__BackingField`), as demonstrated in SmoothAutoRestoreHP v1.1. Legacy Human/Hit lookup remains as a fallback.
- **Gauge speed:** the percentage is now a percentage of **original max HP per second**. The original used a percentage of the remaining *deficit*, which slowed drastically as the gauge approached full. Default remains `0.2% / second`. With 1000 original max HP, that is about 2 gauge points per second. Set 2–5% temporarily when verifying the mod in-game.
- **HP:** the separate existing HP regen settings are retained, including 0.2 combat multiplier by default and target HP percentage.
- **Combat detection:** uses `get_BattleMode()` (0 = idle) with a legacy `get_IsBattleMode()` fallback.
- **Persistence:** each actual changed setting contributes to one save. `json.dump_file()` false returns are now reported. Settings are stored at `reframework/data/CompleteHealthRestoration.json`; the old `reframework/data/renpyon/CompleteHealthRestoration.json` is automatically imported if it exists and the new file does not.
- **Lifecycle:** managed singleton lookups are refreshed rather than cached before loading a game. LateUpdateBehavior is the preferred game tick, with `re.on_frame` as fallback. A time gate prevents duplicate restoration.
- **Safety:** never heals characters with 0 HP; respects pause state, capped gauge and target HP values; read-only diagnostics report writes.

## Quick in-game verification

1. With Loss Gauge restoration enabled, get injured **enough to reduce the maximum HP** (not merely current HP). End the battle.
2. With Gauge rate temporarily set to 5%, open the `Diagnostics (read-only)` panel. Confirm the `Arisen max gauge` number increases toward `original`, and the status reads `Gauge increased (readback confirmed)`.
3. Repeat with a pawn and ensure its Loss Gauge also grows. Turn `Loss Gauge: During battle` off and verify the cap remains unchanged while engaged in combat.
4. Change one checkbox (for example, disable HP healing). Confirm `Config: Saved ...`; restart DD2 and ensure the setting remains disabled.
5. If gauge writes increment but the loss gauge does **not** change, collect `re2_framework_log.txt` and the diagnostics text. This is an experimental build; on-game behavior has **not** been validated.

## Caveats

- A successful `set_ReducedMaxHp` call is not by itself proof that the game will retain the value after a full update tick. The diagnostics indicate whether an **immediate** readback changed; an in-game test after several seconds is still necessary.
- The `AutoHealToMaxHP` option retains its original meaning, but DD2 may clamp current HP at reduced maximum HP until the gauge is restored. This mod does not attempt to bypass that clamp.
- The previous config save bug means some earlier selections may never have reached the old JSON file. The updater cannot recover values that were never written.
- Do not run the legacy original script simultaneously with this update.

## Test evidence

The script compiled under Lua 5.4 and passed mocked REFramework tests for player/pawn HP + gauge regeneration, combat and pause gating, settings migration, multi-field persistence, disabling both systems, silent `json.dump_file` failure, and reload of saved booleans. These are **not live DD2 tests**.
