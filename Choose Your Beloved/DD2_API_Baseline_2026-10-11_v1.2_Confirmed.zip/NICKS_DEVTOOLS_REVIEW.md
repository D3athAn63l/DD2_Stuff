# Nick's Devtools 3.16.7 — supplied source inspection

**Source:** user-attached `Nick's Devtools ... .7z` (21 Lua files extracted for review only). No files from this third-party mod are redistributed in this baseline. This is a code inspection, not a live test.

## Usefulness

- **Choose Your Beloved:** No code targeting `app.NPCHolder` sentiment methods, `getSentimentInfo`, `setSentimentValue`, or `addSentimentValue` was found. The single `app.BattleRelationshipHolder` reference in `CombatTools.lua` is a **combat relationship** API, not evidence for NPC romance affinity. Thus Nick's Devtools is not needed for the working beloved mod or baseline capture.
- **Other DD2 modding:** AI/animation/damage/effect tracers, joint visualizer, position and input tools provide examples of REFramework data access and `sdk.hook` usage.
- **Dragonsplague Perfected:** `NicksDevtools/MiscTools.lua` retrieves pawns' `app.PawnDataContext` and reads/modifies `_PossessionLv` and `_PossessionProgressPoint`, with UI buttons to print/cure/force levels. Potentially helpful for diagnosis but not proof of full plague mechanics.
- A useful overload-specific example: `app.GUIBase:get_method("getName(app.CharacterID)")` in `MiscTools.lua`, matching a signature independently reflected by the v1.2 probe.

## Constraints / caution

- The archive's entry point `reframework/autorun/_NicksDevtools.lua` requires `_NickCore/Properties` and other `_NickCore/*` modules that are **not included in the uploaded archive**. Installing these Lua files alone may error without their separate dependency.
- Several modules register actual `sdk.hook` interceptors upon being loaded. This is a **gameplay-capable devtool**, not a read-only probe. Other UI actions deliberately modify pawn status, position, combat, spawns, and game state; don't run them casually in a valuable save.
- No requirement to install this third-party mod to use the included API baseline or comparison script.
